package com.baml.training.customerApi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baml.training.customerApi.Model.Customer;
import com.baml.training.customerApi.repositories.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository oCustomerRepository;
	
	public Customer addCustomer(Customer oCustomer)
	{
		return oCustomerRepository.save(oCustomer);
	}
	
	public List<Customer> getAllCustomers()
	{
		return oCustomerRepository.findAll();
	}
	
	public Customer getCustomer(Long id)
	{
		return oCustomerRepository.findById(id).orElse(null);
	}
}
