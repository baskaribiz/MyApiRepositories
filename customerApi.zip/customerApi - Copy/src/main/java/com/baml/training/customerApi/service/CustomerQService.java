package com.baml.training.customerApi.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baml.training.customerApi.Model.Customer;
import com.baml.training.customerApi.repositories.CustomerRepository;
import com.coxautodev.graphql.tools.GraphQLQueryResolver;

@Service
public class CustomerQService implements GraphQLQueryResolver {

	@Autowired
	private CustomerRepository oCustomerRepository;
	
	public List<Customer> getAllQCustomers()
	{
		return oCustomerRepository.findAll();
	}
	
	public Customer getQCustomer(Long customerId)
	{
		return oCustomerRepository.findById(customerId).orElse(null);
	}
}
