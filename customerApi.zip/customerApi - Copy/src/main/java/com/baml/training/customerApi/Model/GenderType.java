package com.baml.training.customerApi.Model;

public enum GenderType {
	MALE,
	FEMALE,
	TRANSGENDER
}
